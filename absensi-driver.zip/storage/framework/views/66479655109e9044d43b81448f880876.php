<?php use \Carbon\Carbon; ?>



<?php $__env->startPush('styles'); ?>
  <style>
    body {
      font-family: Arial, sans-serif;
      font-size: 14px;
    }

    .header {
      margin-bottom: 20px;
    }

    .header h1 {
      font-weight: bold;
      font-size: 18px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 11px;
    }

    th, td {
      border: 1px solid black;
      padding: 4px;
      text-align: center;
    }

    th {
      background-color: #f0f0f0;
    }
  </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
  <div class="header">
    <h1>Laporan Absensi</h1>
    <?php if($tanggal): ?>
      <p><?php echo e($tanggal['from']); ?> - <?php echo e($tanggal['to']); ?></p>
    <?php endif; ?>
    <?php if($shift): ?>
      <p><?php echo e($shift); ?></p>
    <?php endif; ?>
  </div>
  <table>
    <thead>
    <tr>
      <th rowspan="2">Tanggal</th>
      <?php if(!$shift): ?>
        <th rowspan="2">Shift</th>
      <?php endif; ?>
      <th rowspan="2">Driver</th>
      <th rowspan="2">Jam</th>
      <th colspan="3">Perjalanan</th>
      <th colspan="3">Bensin</th>
      <th rowspan="2">Tol</th>
      <th rowspan="2">Parkir</th>
      <th rowspan="2">Lain-lain</th>
    </tr>
    <tr>
      <th>Km Awal</th>
      <th>Uraian</th>
      <th>Km Akhir</th>
      <th>Km</th>
      <th>Lt</th>
      <th>Total</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e(Carbon::parse($row->tanggal)->format('d/m/Y')); ?></td>
        <?php if(!$shift): ?>
          <td><?php echo e($row->shift); ?></td>
        <?php endif; ?>
        <td><?php echo e($row->driver_pengganti ?? $row->shift); ?></td>
        <td><?php echo e(Carbon::parse($row->jam_mulai)->format('H:i')); ?> - <?php echo e(Carbon::parse($row->jam_selesai)->format('H:i')); ?></td>
        <td><?php echo e($row->km_awal); ?></td>
        <td><?php echo e($row->uraian_perjalanan); ?></td>
        <td><?php echo e($row->km_akhir); ?></td>
        <td><?php echo e($row->km_bensin); ?></td>
        <td><?php echo e($row->liter); ?></td>
        <td>
          <?php if($row->biaya_bensin): ?>
            <?php echo 'Rp ' . number_format($row->biaya_bensin, 0, ',', '.'); ?>
          <?php endif; ?>
        </td>
        <td>
          <?php if($row->biaya_tol): ?>
            <?php echo 'Rp ' . number_format($row->biaya_tol, 0, ',', '.'); ?>
          <?php endif; ?>
        </td>
        <td>
          <?php if($row->biaya_parkir): ?>
            <?php echo 'Rp ' . number_format($row->biaya_parkir, 0, ',', '.'); ?>
          <?php endif; ?>
        </td>
        <td>
          <?php if($row->biaya_lain_lain): ?>
            <?php echo 'Rp ' . number_format($row->biaya_lain_lain, 0, ',', '.'); ?>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
    <tr>
      <?php
        $total = $data->sum('biaya_bensin') + $data->sum('biaya_tol') + $data->sum('biaya_parkir') + $data->sum('biaya_lain_lain');
      ?>
      <td colspan="<?php echo e(!$shift ? '9' : '8'); ?>" style="text-align: center;"><strong>Jumlah</strong></td>
      <td colspan="4"><strong><?php echo 'Rp ' . number_format($total, 0, ',', '.'); ?></strong></td>
    </tr>
    </tfoot>
  </table>

  <div style="page-break-after: always;"></div>
  <div class="header">
    <h1>Lampiran Foto</h1>
  </div>

  <div style="text-align: center;">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div style="width: 24%; float: left; margin: 0.5%; text-align: center;">
        <img src="<?php echo e(public_path('storage/' . $row->bukti_bensin)); ?>" alt="Bukti Bensin"
             style="width: 100%; height: auto; max-height: 300px; object-fit: contain;">
        <p style="font-size: 12px; margin-top: 5px;">
          <?php echo e(Carbon::parse($row->tanggal)->format('d/m/Y')); ?>_<?php echo e($row->shift); ?>_<?php echo e($row->km_awal); ?>_Bensin
        </p>
      </div>
      <div style="width: 24%; float: left; margin: 0.5%; text-align: center;">
        <img src="<?php echo e(public_path('storage/' . $row->bukti_tol)); ?>" alt="Bukti Tol"
             style="width: 100%; height: auto; max-height: 300px; object-fit: contain;">
        <p style="font-size: 12px; margin-top: 5px;">
          <?php echo e(Carbon::parse($row->tanggal)->format('d/m/Y')); ?>_<?php echo e($row->shift); ?>_Tol
        </p>
      </div>
      <div style="width: 24%; float: left; margin: 0.5%; text-align: center;">
        <img src="<?php echo e(public_path('storage/' . $row->bukti_parkir)); ?>" alt="Bukti Parkir"
             style="width: 100%; height: auto; max-height: 300px; object-fit: contain;">
        <p style="font-size: 12px; margin-top: 5px;">
          <?php echo e(Carbon::parse($row->tanggal)->format('d/m/Y')); ?>_<?php echo e($row->shift); ?>_Parkir
        </p>
      </div>
      <div style="width: 24%; float: left; margin: 0.5%; text-align: center;">
        <img src="<?php echo e(public_path('storage/' . $row->bukti_lain_lain)); ?>" alt="Bukti Tol"
             style="width: 100%; height: auto; max-height: 300px; object-fit: contain;">
        <p style="font-size: 12px; margin-top: 5px;">
          <?php echo e(Carbon::parse($row->tanggal)->format('d/m/Y')); ?>_<?php echo e($row->shift); ?>_Lain-lain
        </p>
      </div>
      <div style="clear: both;"></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div style="clear: both;"></div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Laragon\www\absensi-driver\resources\views\pdf\rekap-absensi.blade.php ENDPATH**/ ?>